Steps to recover you Jumper T-Pro if you have flashed the ELRS internal module with the wrong firmware.

The correct formware target is "Jumper_AION_2400_T-Pro" the one that shipped with the T-Pro was
"DIY_2400_TX_DUPLETX" which is a development target that the ELRS dev team was using when first working on internal module support.

Phase 1 - Upadste EdgeTX to allow passthrough flashing
1. Copy tpro-ada778ee4.bin to your Radio's SD Card in the FIRMWARE folder
2. power off the radio then back on again while holding in the trim switches
3. flash tpro-ada778ee4.bin to your radio and restart when finished

Phase 2 - Recovery!
1. take the 10 screws out of the back of the radio so you can open it like a clam shell
2. Power on the radio
3. Plug in the USB & Select "USB Serial (Debug)"
4. Press and hold the little button on the green circuit board
    this is very fiddly, use a match stick or something small, you should feel it click
5. While holding the button, run recover.bat and wait untill you at least see "Uploading stub..."

If it does not work, power off the radio and try phase 2 again. You may need to do this multiple times!

Troubleshooting

If you see
	module 'serial' has no attribute 'Serial'
then run
	pip install pyserial
